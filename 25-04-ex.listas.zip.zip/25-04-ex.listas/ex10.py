"""Faça um Programa que leia dois vetores com 10 elementos cada. Gere um terceiro vetor de 20 elementos, cujos
valores deverão ser compostos pelos elementos intercalados dos dois outros vetores"""

vetor1 = []
vetor2 = []
vetor3 = []

for i in range(10):
    num1 = float(input(f"Digite o {i + 1}º número: "))
    vetor1.append(num1)

    
for i in range(10):
    num2 = float(input(f"Digite o {i + 1}º número: "))
    vetor2.append(num2)

for i in range(10):
    vetor3.append(vetor1[i])
    vetor3.append(vetor2[i]) 

linha = print(f"===============================================")

print(f"Esse é o 1º vetor: {vetor1}")
print(linha)
print(f"Esse é o 2º vetor: {vetor2}")
print(linha)
print(f"E assim ficou os vetores intercalados: {vetor3}")


