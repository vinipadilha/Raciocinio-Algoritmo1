raiz = int(input("Qual número você deseja saber a raiz?"))

result = (raiz**0.5)

print("Sua razi é: ",result)
