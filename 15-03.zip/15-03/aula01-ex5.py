num1 = float(input("Qual o primeiro número para a soma?"))
num2 = float(input("Qual o segundo número para a soma?"))

result = (num1 + num2)
print("Seu resultado é: ",result)
