aresta = int(input("Qual o tamanho da aresta? (Em centímetros): "))
result = aresta**3
print("A área do seu cubo é: ",result,"centímetros")