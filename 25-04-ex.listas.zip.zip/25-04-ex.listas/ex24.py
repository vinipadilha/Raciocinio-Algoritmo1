"""Faça um programa que simule um lançamento de dados. Lance o dado 100 vezes e armazene os resultados em
um vetor . Depois, mostre quantas vezes cada valor foi conseguido. Dica: use um vetor de contadores(1-6) e uma
função para gerar numeros aleatórios, simulando os lançamentos dos dados"""

num1 = 0
num2 = 0
num3 = 0
num4 = 0
num5 = 0
num6 = 0




