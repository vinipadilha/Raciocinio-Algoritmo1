# CALCULADORA IMC 
peso = int(input("Qual seu peso? (Ex: 60): "))
altura = float(input("Qual sua peso? (Ex: 1.70): "))

result = peso / (altura **2)
print("O seu IMC é ",result)
