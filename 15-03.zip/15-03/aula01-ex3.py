dist = float(input("Qual a distância da sua viagem? Em quilômetros: "))
tempo = float(input("Quanto tempo demorou? Em horas"))

result =  dist / tempo
print("Sua velocidade média foi: ",result)